public class ToyotaSedan extends Car {
    public ToyotaSedan() {
        super("e", 1000, 100, 300, 100000000, "Germany", "2003", "2004");
    }
}
