public class RenaultSedan extends Car{
    public RenaultSedan() {
        super("b", 1000, 100, 300, 100000000, "Germany", "2003", "2004");
    }
}
