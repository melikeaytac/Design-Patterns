public class MercedesSedan extends Car{
    public MercedesSedan() {
        super( "C-Class", 1490.0, 7.1, 240, 38000.0, "Germany", "1.5 months", "4-5 weeks");
    }
}
