public class ToyotaHatchback extends Car {
    public ToyotaHatchback() {
        super("d", 1000, 100, 300, 100000000, "Germany", "2003", "2004");
    }
}
