public class ToyotaSUV extends Car {
    public ToyotaSUV() {
        super("f", 1000, 100, 300, 100000000, "Germany", "2003", "2004");
    }
}
