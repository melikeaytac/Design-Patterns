public class MercedesSUV extends Car{
    public MercedesSUV() {
        super("GVagon", 1000, 100, 300, 100000000, "Germany", "2003", "2004");
    }
}
