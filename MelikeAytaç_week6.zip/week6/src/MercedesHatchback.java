public class MercedesHatchback extends Car{
    public MercedesHatchback() {
        super("polo", 1000, 100, 300, 100000000, "Germany", "2003", "2004");
    }
}
