public interface Chair {
    String sitOn();
}
