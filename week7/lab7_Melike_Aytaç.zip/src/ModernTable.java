public class ModernTable implements Table{
    @Override
    public String placeItem() {
        return "Placing an item on a Modern Table";
    }
}
