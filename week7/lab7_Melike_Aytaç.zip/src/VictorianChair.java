public class VictorianChair implements Chair{
    @Override
    public String sitOn() {
        return "Sitting on a Victorian Chair";
    }
}
