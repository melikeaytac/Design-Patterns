public class VictorianTable implements Table{
    @Override
    public String placeItem() {
        return "Placing an item on a Victorian Table";
    }
}
