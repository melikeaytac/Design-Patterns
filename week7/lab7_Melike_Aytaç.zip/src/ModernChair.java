public class ModernChair implements Chair{
    @Override
    public String sitOn() {
        return "Sitting on a Modern Chair";
    }
}
