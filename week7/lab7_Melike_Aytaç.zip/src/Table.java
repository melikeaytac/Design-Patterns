public interface Table {
    String placeItem();
}

