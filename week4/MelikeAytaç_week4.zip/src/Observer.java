public interface Observer {
    void update(String name,String message);


}
