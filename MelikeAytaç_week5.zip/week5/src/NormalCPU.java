public class NormalCPU extends Server{
    public NormalCPU() {
        description = "Normal CPU Server";
    }

    @Override
    public double getCost() {
        return  0.01484;
    }
}
