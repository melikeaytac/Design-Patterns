public class HighEndCPU extends Server{
    public HighEndCPU() {
        description = "High end CPU server";
    }

    @Override
    public double getCost() {
        return  0.049468;
    }
}
