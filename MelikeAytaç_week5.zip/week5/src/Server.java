 abstract class Server {

    protected String description = "Unknown Server";

    public String getDescription(){
        return description;
    }
    public abstract double getCost();

}
